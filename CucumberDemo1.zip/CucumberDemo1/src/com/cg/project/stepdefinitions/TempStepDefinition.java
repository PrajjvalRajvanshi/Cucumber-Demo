package com.cg.project.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition {

	@Given("^User is on main page www\\.github\\.com$")
	public void user_is_on_main_page_www_github_com() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user gives correct details$")
	public void user_gives_correct_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^A page should return with index page showing details of user$")
	public void a_page_should_return_with_index_page_showing_details_of_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user gives correct Username and incorrect Password$")
	public void user_gives_correct_Username_and_incorrect_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User should be redirected to the same page with error: Username or password is incorrect$")
	public void user_should_be_redirected_to_the_same_page_with_error_Username_or_password_is_incorrect() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user gives incorrect Username and correct Password$")
	public void user_gives_incorrect_Username_and_correct_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	@Then("^A page should return with you are registered successfully displayed on screen$")
	public void a_page_should_return_with_you_are_registered_successfully_displayed_on_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}